-- MySQL dump 10.13  Distrib 5.7.17, for macos10.12 (x86_64)
--
-- Host: localhost    Database: canteen_order_system
-- ------------------------------------------------------
-- Server version	5.7.17

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `cart`
--

DROP TABLE IF EXISTS `cart`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cart` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL COMMENT '用户id',
  `recipe_id` int(11) NOT NULL COMMENT '菜品id',
  `number` int(11) NOT NULL COMMENT '数量',
  `is_delete` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否删除，0:未删除，1:已删除',
  `create_time` datetime DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8 COMMENT='购物车表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cart`
--

LOCK TABLES `cart` WRITE;
/*!40000 ALTER TABLE `cart` DISABLE KEYS */;
INSERT INTO `cart` VALUES (1,3,1,2,0,'2022-07-03 19:44:15','2022-07-05 00:27:12'),(7,5,1,3,0,'2022-07-06 02:15:32','2022-07-06 02:15:39'),(8,7,1,3,1,'2022-07-07 00:31:19','2022-07-07 00:31:28');
/*!40000 ALTER TABLE `cart` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `category`
--

DROP TABLE IF EXISTS `category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL COMMENT '名称',
  `is_delete` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否删除，1:已删除，0:未删除',
  `create_time` datetime DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='分类表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `category`
--

LOCK TABLES `category` WRITE;
/*!40000 ALTER TABLE `category` DISABLE KEYS */;
INSERT INTO `category` VALUES (1,'测试',0,'2022-07-02 16:04:54',NULL);
/*!40000 ALTER TABLE `category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order_item`
--

DROP TABLE IF EXISTS `order_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `order_item` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL COMMENT '订单id',
  `recipe_id` int(11) NOT NULL COMMENT '菜品id',
  `price` double NOT NULL COMMENT '单价',
  `status` int(11) NOT NULL DEFAULT '0' COMMENT '0:待烹饪，1:烹饪中，2:上菜,3:服务员完成上菜',
  `number` int(11) NOT NULL COMMENT '数量',
  `cook_id` int(11) DEFAULT NULL COMMENT '厨师id',
  `sub_total` double NOT NULL COMMENT '单项总和',
  `is_delete` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否删除，0:未删除，1:已删除',
  `create_time` datetime DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  `up_recipe_user_id` int(11) DEFAULT NULL COMMENT '上菜服务员d',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='订单项表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_item`
--

LOCK TABLES `order_item` WRITE;
/*!40000 ALTER TABLE `order_item` DISABLE KEYS */;
/*!40000 ALTER TABLE `order_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `orders`
--

DROP TABLE IF EXISTS `orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `orders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_no` varchar(45) NOT NULL COMMENT '订单编号',
  `total_price` double NOT NULL COMMENT '总金额',
  `user_id` int(11) NOT NULL COMMENT '用户id',
  `table_no` varchar(45) DEFAULT NULL COMMENT '餐桌号',
  `set_user_id` int(11) DEFAULT NULL COMMENT '设置餐桌号人',
  `status` int(11) NOT NULL DEFAULT '0' COMMENT '订单状态，0:用户下单，1:设置餐桌，2:完成上菜，3:支付完成',
  `is_comment` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否评论，0:未评论，1:已评论',
  `is_delete` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否删除，0:未删除，1:已删除',
  `create_time` datetime DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='订单表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orders`
--

LOCK TABLES `orders` WRITE;
/*!40000 ALTER TABLE `orders` DISABLE KEYS */;
/*!40000 ALTER TABLE `orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recipe`
--

DROP TABLE IF EXISTS `recipe`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `recipe` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL COMMENT '名称',
  `category_id` int(11) NOT NULL COMMENT '分类id',
  `image` varchar(255) NOT NULL COMMENT '图片',
  `weightf` varchar(100) NOT NULL COMMENT '份量',
  `price` double(10,2) NOT NULL COMMENT '单价',
  `taste` varchar(45) DEFAULT NULL COMMENT '口味',
  `food` varchar(1000) DEFAULT NULL COMMENT '食材',
  `make_way` varchar(45) DEFAULT NULL COMMENT '制作方式',
  `prompt` varchar(1000) DEFAULT NULL COMMENT '提示',
  `recommend_score` int(11) NOT NULL COMMENT '推荐系数',
  `is_delete` tinyint(1) NOT NULL DEFAULT '0' COMMENT '推荐时间',
  `create_time` datetime DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='菜品表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recipe`
--

LOCK TABLES `recipe` WRITE;
/*!40000 ALTER TABLE `recipe` DISABLE KEYS */;
INSERT INTO `recipe` VALUES (1,'测试',1,'8f5abe9022324b168572c963f368bc43.jpg','1',10.00,'123','1212','112','1212',3,0,NULL,'2022-07-02 16:11:28');
/*!40000 ALTER TABLE `recipe` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `account` varchar(11) NOT NULL COMMENT '账号',
  `password` varchar(32) NOT NULL COMMENT '密码',
  `name` varchar(20) NOT NULL COMMENT '姓名',
  `sex` tinyint(1) NOT NULL DEFAULT '1' COMMENT '性别，1:男，0:女',
  `age` int(2) NOT NULL DEFAULT '20' COMMENT '年龄',
  `mobile` varchar(11) DEFAULT NULL COMMENT '手机号码',
  `type` int(1) NOT NULL DEFAULT '1' COMMENT '类型，0:管理员，1:普通用户，2:后厨，3:服务员',
  `is_delete` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否删除，1:已删除，0:未删除',
  `header_image` varchar(255) NOT NULL DEFAULT 'face.jpg' COMMENT '头像路径',
  `create_time` datetime DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='用户表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,'admin','21232f297a57a5a743894a0e4a801fc3','admin',1,20,'admin',0,0,'8f5abe9022324b168572c963f368bc43.jpg',NULL,'2022-06-27 00:03:38'),(2,'test','098f6bcd4621d373cade4e832627b4f6','test',0,20,'10086',2,0,'face.jpg','2022-06-28 00:39:13','2022-06-28 00:39:49'),(3,'test1','5a105e8b9d40e1329780d62ea2265d8a','test1',1,20,'10086',3,0,'face.jpg','2022-07-02 16:42:10','2022-07-02 16:42:38'),(4,'test3','8ad8757baa8564dc136c1e07507f4a98','test3',1,20,NULL,1,0,'face.jpg','2022-07-05 23:21:18',NULL),(5,'test4','86985e105f79b95d6bc918fb45ec7727','test4',1,20,NULL,1,0,'face.jpg','2022-07-06 02:15:14',NULL),(6,'test5','e3d704f3542b44a621ebed70dc0efe13','test5',1,20,NULL,1,0,'face.jpg','2022-07-06 02:21:33',NULL),(7,'test7','b04083e53e242626595e2b8ea327e525','test7',1,20,NULL,1,0,'face.jpg','2022-07-06 02:24:13',NULL),(8,'test8','5e40d09fa0529781afd1254a42913847','test8',1,20,NULL,1,0,'face.jpg','2022-07-08 22:38:15',NULL);
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_message`
--

DROP TABLE IF EXISTS `user_message`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_message` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `to_user_id` int(11) NOT NULL,
  `type` int(11) NOT NULL COMMENT '类型：1：下单消息，2：上菜消息',
  `is_read` tinyint(1) NOT NULL DEFAULT '0',
  `content` text NOT NULL,
  `create_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_message`
--

LOCK TABLES `user_message` WRITE;
/*!40000 ALTER TABLE `user_message` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_message` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-07-08 23:24:49
