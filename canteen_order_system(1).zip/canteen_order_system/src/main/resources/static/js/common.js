Date.prototype.format = function(format){ 
    var o =  { 
    "M+" : this.getMonth()+1, //month 
    "d+" : this.getDate(), //day 
    "H+" : this.getHours(), //hour 
    "m+" : this.getMinutes(), //minute 
    "s+" : this.getSeconds(), //second 
    "q+" : Math.floor((this.getMonth()+3)/3), //quarter 
    "S" : this.getMilliseconds() //millisecond 
    };
    if(/(y+)/.test(format)){ 
    	format = format.replace(RegExp.$1, (this.getFullYear()+"").substr(4 - RegExp.$1.length)); 
    }
    for(var k in o)  { 
	    if(new RegExp("("+ k +")").test(format)){ 
	    	format = format.replace(RegExp.$1, RegExp.$1.length==1 ? o[k] : ("00"+ o[k]).substr((""+ o[k]).length)); 
	    } 
    } 
    return format; 
};

function inputInteger(obj){
	obj.value = obj.value.toString().length > 0 ? Number(obj.value.toString().replace(/[^0-9]+/ig,'')) : '';
}

function inputFloat(obj){
    var t = obj.value.charAt(0);
    obj.value = obj.value.replace(/[^\d\.]/g,'');
    obj.value = obj.value.replace(/^\./g,'');
    obj.value = obj.value.replace(/\.{2,}/g,'.');
    obj.value = obj.value.replace('.','$#$').replace(/\./g,'').replace('$#$','.');
}
