layui.use(['layer','jquery','form','element','flow'],function(){
	var layer = layui.layer;
	var $ = layui.$;
	var form = layui.form;
	var flow = layui.flow;
	form.render();
	
	var uwindex;
	payOrders = function(){
		var address = form.val("addressForm");
	
		var cartInputs = $("input[name='cartId']");
		var cartIds = new Array();
		for (var i = 0; i < cartInputs.length; i++) {
			if(cartInputs[i].value != null && cartInputs[i].value != ""){
				cartIds.push(cartInputs[i].value);
			}
		}
		var loadIndex = layer.load();
		
		$.ajax({
			type : "post",
			url : "/edu/orders/add",
			data : JSON.stringify(cartIds),
			contentType : "application/json",
			success : function(result){
				layer.close(loadIndex);
				if(result.code != 200){
					layer.msg(result.message,{icon:5,anim:6});
					return ;
				}
				layer.msg(result.message,{icon:1});
				setTimeout(function(){
					window.location.href = "/orders";
				},1500);
				/*var data =result.data
				uwindex = layer.open({
					type : 1,
					title : "确认付款",
					content : $("#confirm-template").text(),
					btn : ['取消','确定'],
					btn2 : function(index,layero){
						$("#confirm-form").attr("action","/edu/orders/update");
						$("#confirm-form").attr("method","post");
						$("#confirm-form #submit-btn").click();
						return false;
					},
					success : function(){
						$("#orderNo").text(data);
						form.val("confirm-form",{
							"no" : data
						})
						$("#confirmTotal").text($("#total").text());
					}
				})*/
			}
		})
	}
	form.on("submit(confirm-form)",function(data){
		var param = data.field;
		var loadIndex = layer.load()
		$.ajax({
			type : "post",
			url : "/edu/orders/confirmPay",
			data : param,
			success : function(result){
				layer.close(loadIndex);
				if(result.code != 200){
					layer.msg(result.message,{icon:5,anim:6});
					return ;
				}
				var data = result.data;
				layer.close(uwindex);
				layer.msg(result.message,{icon:1});
				$("#payBtn").hide();
			}
		})
		return false;
	})
})