layui.use(['layer', 'jquery', 'form'], function() {
	var layer = layui.layer;
	var $ = layui.jquery;
	var form = layui.form;
	$("#bgImg").height($(window).height());
	$("#bgImg").width($(window).width());
	layer.open({
		type: 1,
		title: false,
		closeBtn: false,
		area: ['350px', '410px'],
		shade: 0,
		anim: 2,
		content: $("#registerFormDiv"),
		success: function() {
			$("#registerFormDiv").removeClass("layui-hide");
		}
	})

	form.on("submit(register-form)", function(data) {
		var loadIndex = layer.load();
		$.ajax({
			type : "post",
			url : "/edu/user/register",
			data : JSON.stringify(data.field),
			contentType : "application/json",
			success : function(result){
				layer.close(loadIndex);
				if(result.code != 200){
					layer.msg(result.message,{icon:5,anim:6});
					return ;
				}
				layer.msg(result.message,{icon:1});
				setTimeout(function(){
					window.location.href = result.data;
				},1500);
			},
			error : function(result){
				layer.close(loadIndex);
				layer.msg("服务器出错",{icon:2});
			}
		})
		return false;
	})
})
