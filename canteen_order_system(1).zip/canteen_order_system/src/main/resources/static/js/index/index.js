layui.use(['layer', 'jquery', 'form', 'element', 'carousel','rate'], function() {
	var layer = layui.layer;
	var $ = layui.jquery;
	var form = layui.form;
	var element = layui.element;
	var rate = layui.rate;
	var carousel = layui.carousel;
	element.render();
	
	var recipes = $(".recipe-comments");
	for(var i =0;i<recipes.length;i++){
		var recommendScore = $(recipes[i]).parent().find("input[name='recommendScore']").val();
		rate.render({
			elem:"#"+recipes[i].id,
			value:recommendScore,
			readonly : true
		})
	}
});
