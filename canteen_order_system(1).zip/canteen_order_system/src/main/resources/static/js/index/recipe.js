layui.use(['layer', 'jquery', 'form', 'element', 'carousel','rate'], function() {
	var layer = layui.layer;
	var $ = layui.jquery;
	var form = layui.form;
	var element = layui.element;
	var rate = layui.rate;
	var carousel = layui.carousel;
	element.render();
	carousel.render({
		elem: '#carousel'
		, width: '100%'
		, height: "500px"
		, arrow: 'none'
	});
	var recipes = $(".recipe-comments");
	for(var i =0;i<recipes.length;i++){
		var sum = $(recipes[i]).parent().find("input[name='recipe-sum']").val();
		var count = $(recipes[i]).parent().find("input[name='recipe-count']").val();
		var id = $(recipes[i]).parent().find("input[name='recipe-id']").val();
		console.log(id);
		$(recipes[i]).parent().find(".comments-count").text(count);
		rate.render({
			elem:"#"+recipes[i].id,
			value:sum,
			readonly : true
		})
	}
});
