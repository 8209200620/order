layui.use(['layer', 'jquery', 'form', 'element', 'carousel','rate','flow'], function() {
	var layer = layui.layer;
	var $ = layui.jquery;
	var form = layui.form;
	var element = layui.element;
	var rate = layui.rate;
	var flow = layui.flow;
	
	addCart = function(recipeId){
		var loadIndex = layer.load();
		$.ajax({
			type : "post",
			url : "/edu/cart/add",
			data : JSON.stringify({
				recipeId : recipeId			
			}),
			contentType : "application/json",
			success : function(result){
				layer.close(loadIndex);
				validIsLogin(result);
				if(result.code != 200){
					layer.msg(result.message,{icon:5,anim:6});
					return ;
				}
				
				layer.msg(result.message,{icon:1});
			}
		})	
	}
	
	
	loadRecipeComments = function(){
		var id = $("#recipeId").val();
		flow.load({
		    elem: '#recipeComments' 
		    ,done: function(page, next){ 
		    	$.ajax({
		    		type : "get",
		    		url : "/edu/comments/list?recipeId="+id,
		    		async : false,
		    		data : {
		    			page : page,
		    			rows : 10
		    		},
		    		success : function(result){
		    			if(result.code != 200){
		    				layer.msg(result.message,{icon:5,anim:6});
		    				return ;
		    			}
		    			var data = result.data.data;
		    			if(data == null){
		    				data = [];
		    			}
		    			var commentsData = [];
		    			var rateDatas = [];
		    			for (var i = 0; i < data.length; i++) {
		    				var content = "";
		    				rateDatas.push({id:'score'+data[i].id,value:data[i].score});
		    				content += "<div class='layui-row' style='padding-top: 10px; padding-bottom:10px;padding-right: 10px;'>"
		    						+"<div class='layui-col-md1' style='text-align: center;height:80px;'>"
		    						+"<img src='"+data[i].user.headerImage+"' style='width: 50px; height: 50px; border-radius: 50%;' />"
		    						+"</div>"
		    						+"<div class='layui-col-md3'>"
		    						+"<b>"+data[i].user.name+"</b>"
		    						+"</div>"
		    						+"<div class='layui-col-md2'>"
		    						+"<div id='score"+data[i].id+"'></div>"
		    						+"</div>"
		    						+"<div class='layui-col-md6 layui-word-aux' style='text-align: right;'>"
		    						+data[i].createTime
		    						+"</div>"
		    						+"<div class='layui-col-md11'>"
		    						+"<div class='layui-col-md9' style='padding-top: 10px;'>"
		    						+data[i].content
		    						+"<div>"
		    						+"</div></div></div>";
		    				commentsData.push(content);
						}
		    			next(commentsData.join(''), page < result.data.pages);
		    			for (var j = 0; j < rateDatas.length; j++) {
		    				var rateData = rateDatas[j];
		    				 rate.render({
		    				      elem: '#'+rateData.id,
		    				      value : rateData.value,
		    				      readonly:true
		    				 });
						}
		    		}
		    	})
		    }
		});
	}
	
	$(function(){
		loadRecipeComments();
	})
});
