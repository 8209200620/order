layui.use(['layer','jquery','form','element','flow'],function(){
	var layer = layui.layer;
	var $ = layui.$;
	var form = layui.form;
	var flow = layui.flow;
	form.render();
	
	addNumber = function(id,obj){
		;
		var productTotalNumner = new Number($(obj).parent().find("#productTotalNumner").text());
		
		var totalNumner = new Number($(obj).parent().find("#totalNumber").text());
		
		var loadIndex = layer.load();
		var param = {
				recipeId : id,
		};
		$.ajax({
			type : "post",
			url : "/edu/cart/add",
			data : JSON.stringify(param),
			contentType : "application/json",
			success : function(result){
				layer.close(loadIndex);
				if(result.code != 200){
					layer.msg(result.message,{icon:5,anim:6});
					return ;
				}
				$(obj).parent().find("#totalNumber").text(totalNumner+1);
				var value = $(obj).parent().parent().find("input[type='checkbox']").val();
				value = JSON.parse(value);
				value.number = value.number+1;
				$(obj).parent().parent().find("input[type='checkbox']").val(JSON.stringify(value));
				loadPrice();
				$(obj).parent().parent().find("#recipeSubTotal").text(new Number(value.recipe.price*value.number).toFixed(2));
			}
		
		})
		
	}
	
	subNumber = function(id,obj){
		var productTotalNumber = new Number($(obj).parent().find("#productTotalNumner").text());
		
		var totalNumber = new Number($(obj).parent().find("#totalNumber").text());
		if(parseInt(totalNumber) == 1){
			return ;
		}
		var param = {
				recipeId : id
		};
		var loadIndex = layer.load();
		$.ajax({
			type : "post",
			url : "/edu/cart/sub",
			data : JSON.stringify(param),
			contentType : "application/json",
			success : function(result){
				layer.close(loadIndex);
				if(result.code != 200){
					layer.msg(result.message,{icon:5,anim:6});
					return ;
				}
				$(obj).parent().find("#totalNumber").text(totalNumber-1);
				var value = $(obj).parent().parent().find("input[type='checkbox']").val();
				value = JSON.parse(value);
				value.number = value.number-1;
				$(obj).parent().parent().find("input[type='checkbox']").val(JSON.stringify(value));
				loadPrice();
				$(obj).parent().parent().find("#recipeSubTotal").text(new Number(value.recipe.price*value.number).toFixed(2));
			}
		})
		
	}
	
	loadPrice = function(){
		var totalPrice = 0;
		var checkedNumber = $("#cartForm input[type='checkbox']:checked").length;
		$("#cartForm input[type='checkbox']:checked").each(function(index,item){
			var cart = JSON.parse(item.value);
			var price = cart.number * cart.recipe.price;
			totalPrice+=price;
		})
		$("#checkProductNumber").text(checkedNumber);
		$("#totalPrice").text(totalPrice.toFixed(2));
	}
	
	loadCart = function(){
		var userId = $("#userId").val();
		var loadIndex = layer.load();
		flow.load({
		    elem: '#cartData'
		    ,isAuto:false
		    ,end : "<div class='layui-col-md12' style='margin-top:20px;text-align:center;'>没有更多了</div>"
		    ,done: function(page, next){ 
		    	$.ajax({
		    		type : "get",
		    		url : "/edu/cart/list",
		    		data : {
		    			page : page,
		    			rows : 5,
		    			userId : userId
		    		},
		    		success : function(result){
		    			layer.close(loadIndex);
		    			if(result.code != 200){
		    				layer.msg(result.message,{icon:5,anim:6});
		    				return ;
		    			}
		    			var data = result.data.data;
		    			var cartData = [];
		    			for (var i = 0; i < data.length; i++) {
		    				var subNumer = new Number(data[i].recipe.price*data[i].number);
		    				var content = "<div class='layui-col-md12' style='margin-left: 10px;margin-top: 10px;background-color: white;border-radius: 5px;height: 100px;padding-top: 10px;padding-bottom: 10px;'>"
		    							+"<div class='layui-col-md1' style='height: 80px;'>"
		    							+"<div style='margin-top: 25px;text-align: center;'>"
		    							+"<input type='checkbox' lay-skin='primary' lay-filter='checkProduct' name='id' value='"+JSON.stringify(data[i])+"' />"
		    							+"</div>"
		    							+"</div>"
		    							+"<div class='layui-col-md2' style='height: 80px;'>"
		    							+"<div style='text-align: center;'>"
		    							+"<img src='"+data[i].recipe.image+"' height='80px' />"
		    							+"</div>"
		    							+"</div>"
		    							+"<div class='layui-col-md3' style='height: 80px;'>"
		    							+"<div class='layui-text layui-word-aux' style='margin-top: 15px;' ><a href='/recipe-detail?id="+data[i].recipe.id+"' style='font-size: 18px;cursor: pointer;color: #a3a3a3;'>"+data[i].recipe.name+"</a></div>"
		    							+"<div class='layui-text layui-word-aux' >"+data[i].recipe.food+"</div>"
		    							+"</div>"
		    							+"<div class='layui-col-md1' style='height: 80px;line-height: 80px;font-size: 18px; color:#FF5722;text-align: center;'>"
		    							+data[i].recipe.price
		    							+"</div>"
		    							+"<div class='layui-col-md2' style='height: 80px;line-height: 80px;font-size: 18px;text-align: center;'>"
		    							+"<i class='layui-icon layui-icon-reduce-circle' style='cursor: pointer;' onclick='subNumber("+data[i].recipe.id+",this)'></i>"
		    							+"&nbsp;&nbsp;"
		    							+"<span id='totalNumber'>"+data[i].number+"</span>"
		    							+"&nbsp;&nbsp;"
		    							+"<i class='layui-icon layui-icon-add-circle' style='cursor: pointer;' onclick='addNumber("+data[i].recipe.id+",this)'></i>"
		    							+"<span class='layui-word-aux layui-text'><span id='productTotalNumner'></span></span>"
		    							+"</div>"
		    							+"<div class='layui-col-md1' id='recipeSubTotal' style='height: 80px;line-height: 80px;font-size: 18px; color:#FF5722;text-align: center;'>"
		    							+subNumer.toFixed(2)
		    							+"</div>"
		    							+"<div class='layui-col-md1' style='height: 80px;color:#FF5722;line-height: 80px;text-align: center;'>"
		    							+"<div style='cursor: pointer;' onclick='deleteCart("+data[i].id+")'>删除</div>"
		    							+"</div>"
		    							+"</div>";
							cartData.push(content);
						}
		    			next(cartData.join(''), page < result.data.pages);
		    			form.render();
		    			$(".layui-flow-more").addClass("layui-col-md8");
		    		}
		    	})
		    }
		  });
	}
	
	loadCart();
	
	deleteCart = function(id){
		layer.confirm("确定要删除该菜品吗？",{
			title : false,
			closeBtn : false,
			btn : ['取消','确定'],
			btn2 : function(index,layero){
				var loadIndex = layer.load();
				$.ajax({
					type : "get",
					url : "/edu/cart/delete/"+id,
					success : function(result){
						layer.close(loadIndex);
						if(result.code != 200){
							layer.msg(result.message,{icon:5,anim:6});
							return ;
						}
						layer.msg(result.message,{icon:1});
						setTimeout(function(){
							window.location.reload();
						},1500)
					}
				})
			}
		});
	}
	
	form.on('checkbox(checkAll)', function(data){
		$("#cartForm input[type='checkbox']").each(function (index, item) {
			item.checked = data.elem.checked;
		});
		var totalPrice = 0;
		if(data.elem.checked){
			var checkProductNumber = $("#cartForm input[type='checkbox']").length;
			$("#checkProductNumber").text(checkProductNumber);
			$("#cartForm input[type='checkbox']").each(function(index,item){
				var cart = JSON.parse(item.value);
				var cartTotalPrice = cart.recipe.price * cart.number;
				totalPrice+=cartTotalPrice;
			})
			$("#totalPrice").text(totalPrice.toFixed(2));
		}else{
			$("#checkProductNumber").text(0);
			$("#totalPrice").text(totalPrice.toFixed(2));
		}
		
		form.render();
	}); 
	
	form.on('checkbox(checkProduct)', function(data){
		var cartData = JSON.parse(data.value);
		var cartPrice = cartData.recipe.price*cartData.number;
		if(data.elem.checked){
			var checkProductNumber = new Number($("#checkProductNumber").text());
			$("#checkProductNumber").text(checkProductNumber+1);
			var totalPrice = new Number($("#totalPrice").text());
			$("#totalPrice").text(new Number(totalPrice+cartPrice).toFixed(2));
		}else{
			var checkProductNumber = new Number($("#checkProductNumber").text());
			var totalPrice = new Number($("#totalPrice").text());
			$("#totalPrice").text(new Number(totalPrice-cartPrice).toFixed(2));
			$("#checkProductNumber").text(checkProductNumber-1);
		}
		var checkedNumber = $("#cartForm input[type='checkbox']:checked").length;
		var checkboxNumber = $("#cartForm input[type='checkbox']").length;
		if(checkedNumber == checkboxNumber){
			$(".checkAll").each(function(index,item){
				item.checked = data.elem.checked;
			})
		}else{
			$(".checkAll").each(function(index,item){
				item.checked = false;
			})
		}
		form.render();
	});  
	payOrders = function(){
		var checkedNumber = $("#cartForm input[type='checkbox']:checked");
		if(checkedNumber.length == 0){
			layer.msg("至少选择一个菜品",{icon:5,anim:6});
			return ;
		}
		layer.load();
		var ids = "";
		for (var i = 0; i < checkedNumber.length; i++) {
			var cart = JSON.parse(checkedNumber[i].value);
			ids += "ids="+cart.id+"&";
		}
		
		setTimeout(function(){
			window.location.href = "/pay-order?"+ids+"isCart=true";
		},1000)
	}
})