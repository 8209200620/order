var uwindex;
layui.use(['layer', 'jquery', 'element', 'upload', 'form','flow','util'], function() {
	var layer = layui.layer;
	var $ = layui.jquery;
	var form = layui.form;
	var upload = layui.upload;
	var element = layui.element;
	var flow = layui.flow;
	var util = layui.util;
	
	logout = function(id) {
		layer.confirm("确定要退出吗？", {
			title: false,
			closeBtn: false,
			btn: ['取消', '确定'],
			btn2: function(index, layero) {
				var loadIndex = layer.load();
				
				$.ajax({
					type: "get",
					url: "/edu/user/logout",
					success: function(result) {
						layer.close(loadIndex);
						validIsLogin(result);
						if (result.code != 200) {
							layer.msg(result.message, {
								icon: 5,
								anim: 6
							});
							return;
						}
						layer.close(index);
						layer.msg(result.message, {
							icon: 1
						});
						setTimeout(function() {
							window.location.href = result.data;
						}, 1200);
					},
					error: function(result) {
						layer.close(loadIndex);
						layer.msg("服务器出错", {
							icon: 2
						});
					}
				});
				return false;
			}
		})
	}

	validIsLogin = function(result) {
		layui.use(['layer'], function() {
			if (result.code == 502) {
				layer.msg(result.message, {
					icon: 5
				});
				setTimeout(function() {
					window.location.href = result.data;
				}, 1500);
			}
			return;
		});
	}
	currUserInfo = function(id) {
		$.ajax({
			type: "get",
			url: '/edu/user/' + id,
			success: function(result) {
				var data = result.data;
				uwindex = layer.open({
					type: 1,
					title: "用户信息",
					content: $("#user-detail-template").text(),
					btn: ['取消', '确定'],
					area: ["560px", '400px'],
					btn2: function(index, layero) {
						$("#user-detail-form").attr("action",
							"/edu/user/updateCurrUser");
						$("#user-detail-form").attr("method", "post");
						$("#user-detail-form #submit-btn").click();
						return false;
					},
					success: function() {
						form.render();
						form.val("user-detail-form", {
							"id": data.id,
							"account": data.account,
							"password": data.password,
							"name": data.name,
							"sex": data.sex == true ? "1" : "0",
							"mobile": data.mobile,
							"age": data.age,
							"headerImage": data.headerImage,
						});

						$("#user-detail-form #headerImage").attr("src",
							"/" + data.headerImage);
						upload.render({
							elem: '#headerImageBtn',
							url: '/upload/file',
							before: function(obj) {
								obj.preview(function(index,
									file, result) {
									$('#user-detail-form #headerImage')
										.attr('src',
											result);
								});
							},
							accept: "images",
							done: function(result) {
								if (result.code != 200) {
									return layer.msg(result
										.message, {
											icon: 5
										});
								}
								$("#user-detail-form input[name='headerImage']")
									.val(result.data);
							}
						});
					}
				})
			}
		})
	}

	form.on("submit(user-detail-form)", function(fromData) {
		var action = $("#user-detail-form").attr("action");
		var method = $("#user-detail-form").attr("method");
		var params = fromData.field;
		params.sex = params.sex == 1 ? true : false;
		var loadIndex = layer.load();
		$.ajax({
			type: "post",
			url: action,
			data: JSON.stringify(params),
			contentType: "application/json",
			success: function(result) {
				layer.close(loadIndex);
				if (result.code != 200) {
					layer.msg(result.message, {
						icon: 5,
						anim: 6
					});
					return;
				}
				layer.msg(result.message, {
					icon: 1
				});
				layer.close(uwindex);
				setTimeout(function() {
					window.location.reload();
				}, 1200)
			},
			error: function(result) {
				layer.close(loadIndex);
				layer.msg("服务器出错", {
					icon: 2
				});
			}
		})
		return false;
	})


	updatePassword = function(id) {
		uwindex = layer.open({
			type: 1,
			title: "修改密码",
			content: $("#update-password-template").text(),
			btn: ['取消', '确定'],
			btn2: function(index, layero) {
				$("#update-password-form #submit-btn").click();
				return false;
			},
			success : function(){
				form.val("update-password-form", {
					"id": id
				});
			}
		})

	}

	form.on("submit(update-password-form)", function(data) {
		var param = data.field;
		
		if (param.password != param.rePassword) {
			layer.msg("两次密码不一致", {
				icon: 5,
				anim: 6
			});
			return false;
		}
		var loadIndex = layer.load();
		
		
		$.ajax({
			type: "post",
			url: "/edu/user/updatePassword",
			data: JSON.stringify(data.field),
			contentType: "application/json",
			success: function(result) {
				layer.close(loadIndex);
				if (result.code != 200) {
					layer.msg(result.message, {
						icon: 5,
						anim: 6
					});
					return;
				}
				layer.msg(result.message, {
					icon: 1
				});
				layer.close(uwindex);
				setTimeout(function() {
					window.location.reload();
				}, 1200)
			},
			error: function(result) {
				layer.close(loadIndex);
				layer.msg("服务器出错", {
					icon: 2
				});
			}
		})
		return false;
	})
	
	$(function(){
		var onlineUserId = $("#onlineUserId").val();
		if(onlineUserId != null && ""!= onlineUserId){
			$.ajax({
					type: "get",
					url: "/edu/user/message/count",
					data : {
						userId : onlineUserId
					},
					success: function(result) {
						validIsLogin(result);
						if (result.code != 200) {
							layer.msg(result.message, {
								icon: 5,
								anim: 6
							});
							return;
						}
						var count = result.data;
						
						var notReadCountElement = $("#notReadCount").text();
				
						if(notReadCountElement != null && notReadCountElement != ""){
							notReadCountElement.text(count);
						}else{
							var messageCount = $("#messageCount");
							messageCount.html("<span class='layui-badge' style='position: absolute;top:0;right: 0;' id='notReadCount'>"+count+"</span>");
						}
						
					},
					error: function(result) {
						layer.close(loadIndex);
						layer.msg("服务器出错", {
							icon: 2
						});
					}
				});
		}
	})
	setTimeAgo = function(y, M, d, H, m, s){
	    var str = util.timeAgo(new Date(y, M||0, d||1, H||0, m||0, s||0));
	    return str;
	}
	showMessage =function(){
		var height = $(window).height() + "px";
		var onlineUserId = $("#onlineUserId").val();
		upwindex = layer.open({
			type: 1,
			title: "最新消息",
			offset: 'r',
			area: ["300px", height],
			anim: 1,
			content: $("#show-message-template").text(),
			success: function() {
				flow.load({
					elem: '#show-message-div',
					done: function(page, next) {
						var loadIndex = layer.load();
						$.ajax({
							type: "get",
							url: "/edu/user/message/list",
							data : {
								page : page,
								rows  : 10,
								userId : onlineUserId
							},
							success: function(result) {
								layer.close(loadIndex);
								if (result.code != 200) {
									layer.msg(result.message, { icon: 5, anim: 6 });
									return;
								}
								var data = result.data.data;
								var messageData = [];
								var date = new Date();
								for (var i = 0; i < data.length; i++) {
									var content = "";
									date.setTime(data[i].dateStr);
									var typeStr = data[i].type == 1?"下单消息":data[i].type == 2?"上菜消息":"烹饪消息";
									var dateStr = setTimeAgo(date.getFullYear(), date.getMonth(), date.getDate(), date.getHours(), date.getMinutes(), date.getSeconds());
									content = '<div class="layui-col-md12 show-message" style="padding:10px;background-color:#f1f1f1;cursor:pointer;margin-bottom:5px;">' +
										'<div class="layui-col-md2 layui-circle" style="height:45px;background-color:#2F4056;text-align:center;line-height:45px;margin-top:5px">' +
										'<i class="layui-icon layui-icon-notice" style="color:#ffffff;font-size:22px;"></i></div>' +
										'<div class="layui-col-md10" style="padding-left:10px;padding-right:10px;">' +
										'<div class="layui-col-md4 layui-word-aux" style="margin-top:5px; font-size:13px;">' + typeStr + '</div>' +
										'<div class="layui-col-md8 layui-word-aux" style="margin-top:5px;text-align:right;font-size:13px;">' + dateStr + '</div>' +
										'<div class="layui-col-md12 " style="font-size:12px;">' + data[i].content + '</div>' +
										'</div></div>';
									messageData.push(content);
								}
								next(messageData.join(''), page < result.data.pages);
							}
						})
					}
				})
			}
		})
	}
	showDetail = function(content){
		layer.tips("1222");
	}
})
