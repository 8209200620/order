var addUser;
layui.use(['layer', 'element', 'jquery', 'upload', 'form', 'table'], function() {
	var layer = layui.layer;
	var element = layui.element;
	var $ = layui.jquery;
	var upload = layui.upload;
	var form = layui.form;
	var table = layui.table;
	$(".layui-nav-tree .comments-manager").addClass("layui-nav-itemed");
	$(".layui-nav-tree .comments-info").addClass("layui-this");
	
	table.render({
		elem: "#data-table",
		url: "/edu/comments/list",
		request: {
			pageName: "page",
			limitName: "rows"
		},
		page: true,
		response: {
			statusCode: 200,
			statusName: "code",
			countName: "total",
			dataName: "data",
			msgName: "message"
		},
		parseData: function(result) {
			validIsLogin(result);
			if (result.code != 200) {
				return {
					code: result.code,
					message: result.message,
					data: null,
					total: 0
				}
			}

			return {
				code: result.code,
				data: result.data.data,
				total: result.data.total
			}
		},
		cols: [
			[{
					title: "序号",
					type: "numbers",
					fixed: "right"
				},
				{
					title: "用户",
					align: "center",
					unresize: true,
					templet : function(row){
						return row.user.name;					
					}
				},
				{
					title: "菜品",
					align: "center",
					unresize: true,
					templet : function(row){
						return row.recipe.name;					
					}
				},
				{
					title: "星数",
					field: "score",
					align: "center",
					unresize: true
				},
				{
					title: "内容",
					field: "content",
					align: "center",
					unresize: true
					
				},
				{
					title: "创建时间",
					field: "createTime",
					align: "center",
					unresize: true
				},
				{
					title: "更新时间",
					field: "updateTime",
					align: "center",
					unresize: true
				},
				{
					title: "操作",
					align: "center",
					unresize: true,
					templet: function(row) {
						var buttons = "";
						
						buttons += "<button class='layui-btn layui-btn-xs layui-btn-danger' onclick='deleteComments(" +
								row.id + ")'>删除</button>";
						return buttons;

					}
				}
			]
		]
	})

	

	deleteComments=function(id) {
		layer.confirm("确定要删除该评论吗？", {
			title: false,
			closeBtn: false,
			btn: ['取消', '确定'],
			btn2: function(index, layero) {
				var loadIndex = layer.load();
				$.ajax({
					type : "get",
					url : '/edu/comments/delete/' + id,
					success : function(result){
						layer.close(loadIndex);
						validIsLogin(result);
						if (result.code != 200) {
							layer.msg(result.message, {
								icon: 5
							});
							return;
						}
						layer.msg(result.message, {
							icon: 1
						});
						table.reload("data-table");
					}
				})
			}
		})
	}
})