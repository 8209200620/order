layui.config({
	base: '/layui/lay/modules/',   // 模块所在目录
}).extend({                         
	layarea : 'opTable'  // 模块别名
});
layui.use(['layer', 'element', 'jquery', 'upload', 'form', 'table','opTable'], function() {
	var layer = layui.layer;
	var element = layui.element;
	var $ = layui.jquery;
	var upload = layui.upload;
	var form = layui.form;
	var table = layui.table;
	var opTable = layui.opTable;
	$(".layui-nav-tree .orders-manager").addClass("layui-nav-itemed");
	$(".layui-nav-tree .orders-info").addClass("layui-this");
	
	var dataOpTable =  opTable.render({
		elem : '#data-table',
		id : '#data-table',
		url : '/edu/orders/list',
		request : {
			pageName : "page",
			limitName : "rows"
		},
		where : {
			status : 0
		},
		page : true,
		response : {
			statusCode : 200,
			statusName : "code",
			countName : "total",
			dataName : "data",
			msgName : "message"
		},
		parseData : function(result) {
			if (result.code != 200) {
				return {
					code : result.code,
					message : result.message,
					data : null,
					total : 0
				}
			}
			return {
				code : result.code,
				data : result.data.data,
				total : result.data.total
			}
		},
		cols : [ [ 
		{
			title : "订单号",
			field : 'orderNo',
			align : "center",
			unresize : false
		}, 
		{
			title : "用户",
			align : "center",
			unresize : false,
			templet : function(row){
				return row.user.name;
			}
		}, 
		{
			title : "总金额",
			field : 'totalPrice',
			align : "center",
			unresize : false
		}, 
		{
			title : "餐桌号",
			field : 'tableNo',
			align : "center",
			unresize : false
		}, 
		{
			title : "状态",
			align : "center",
			templet : function(row){
				return	"待设置餐桌";
			}
		},
		{
			title : "管理",
			align : "center",
			templet : function(row){
				var buttons = "";
				if(row.status == 0){
					buttons +="<button class='layui-btn layui-btn-xs layui-btn-primary' onclick='setTableNo("+row.id+")'>设置餐桌号</button>";
				}
				return buttons;
			}
		}
		]],
		openCols: [
	        {
	        	templet: function (item) {
	        		var content ="";
	        		$.ajax({
	        			type : "get",
	        			url : "/edu/orders/detail",
	        			async : false,
	        			data : {
	        				id:item.id
	        			},
	        			success : function(result){
	        				if(result.code != 200){
	        					layer.msg(result.message,{icon:5,anim:6});
	        					return ;
	        				}
	        				var data = result.data;
	        				content = "<div class='layui-row'>" 
	        							+"<div class='layui-col-md12' style='border:1px solid #bed7ff;'>"
	        							+"<div class='layui-col-md5' style='text-align: center;margin-top: 5px;padding-top: 10px;padding-bottom: 10px;'>菜品信息</div>"
	        							+"<div class='layui-col-md2' style='text-align: center;margin-top: 5px;padding-top: 10px;padding-bottom: 10px;'>单价</div>"
	        							+"<div class='layui-col-md3' style='text-align: center;margin-top: 5px;padding-top: 10px;padding-bottom: 10px;'>数量</div>"
	        							+"<div class='layui-col-md1' style='text-align: center;margin-top: 5px;padding-top: 10px;padding-bottom: 10px;'>小计</div>"
	        							+"<div class='layui-col-md1' style='text-align: center;margin-top: 5px;padding-top: 10px;padding-bottom: 10px;'>状态</div>"
	        							+"</div>";
	        				for (var i = 0; i < data.length; i++) {
	        					var itemStatus = data[i].status == 0?"待烹饪":data[i].status == 1?"烹饪中":"已上菜";
								content+="<div class='layui-col-md12' style='padding-top: 10px;padding-bottom: 10px;border-bottom: 1px solid #bed7ff;background-color: #fbfcff;border-left: 1px solid #bed7ff;border-right: 1px solid #bed7ff;'>"
    							+"<div class='layui-col-md2' style='height: 80px;'>"
								+"<div style='text-align: center;'>"
									+"<img src='/"+data[i].recipe.image+"' height='80px' />"
								+"</div>"
								+"</div>"
								+"<div class='layui-col-md3' style='height: 80px;'>"
								+"<div class='layui-text layui-word-aux' style='margin-top: 15px;'>"
									+"<a href='javascript:void(0);' style='font-size: 18px; cursor: pointer; color: #a3a3a3;'>"+data[i].recipe.name+"</a>"
								+"</div>"
								+"<div class='layui-text layui-word-aux'>"+data[i].recipe.category.name+"</div>"
								+"</div>"
								+"<div class='layui-col-md2' style='height: 80px; line-height: 80px; font-size: 18px; color: #FF5722; text-align: center;'>"+data[i].recipe.price+"</div>"
								+"<div class='layui-col-md3' style='height: 80px; line-height: 80px; font-size: 18px; text-align: center;'>"
								+"<span id='totalNumber'>"+data[i].number+"</span>"
								+"</div>"
								+"<div class='layui-col-md1' style='height: 80px; color: #FF5722; line-height: 80px; text-align: center;'>"
								+"<div>"+data[i].subTotal+"</div>"
								+"</div>"
								+"<div class='layui-col-md1' style='height: 80px; line-height: 80px; text-align: center;'>"
								+"<div>"+itemStatus+"</div>"
								+"</div>"
								+"</div>";
							}
	        				content+="</div>";
	        			}
	        		})
	        		return content;
	        	}
	        }
	     ]
	})
	
	setTableNo = function(id){
		var template = $("#set-table-no-template").text();
		layer.confirm(template, {
			title: false,
			closeBtn: false,
			btn: ['取消', '确定'],
			btn2: function(index, layero) {
				var tableNo = $("#tableNo").val();
				if(tableNo == null || tableNo == ""){
					layer.msg("餐桌号不能为空",{icon:5,anim:6});
					return false;
				}
				var loadIndex = layer.load();
				$.ajax({
					type : "post",
					url : '/edu/orders/setTableNo',
					data : {
						id : id,
						tableNo : tableNo
					},
					success : function(result){
						layer.close(loadIndex);
						validIsLogin(result);
						if (result.code != 200) {
							layer.msg(result.message, {
								icon: 5
							});
							return;
						}
						layer.msg(result.message, {
							icon: 1
						});
						dataOpTable.reload();
					}
				})
			}
		})
	}
	
})