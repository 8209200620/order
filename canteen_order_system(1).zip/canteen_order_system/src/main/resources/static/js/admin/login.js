layui.use(['layer', 'jquery', 'form'], function() {
	var layer = layui.layer;
	var $ = layui.jquery;
	var form = layui.form;
	$("#bgImg").height($(window).height());
	$("#bgImg").width($(window).width());
	
	layer.open({
		type: 1,
		title: false,
		closeBtn: false,
		area: ['350px', '360px'],
		shade: 0,
		anim: 2,
		content: $("#loginFormDiv"),
		success: function() {
			$("#loginFormDiv").removeClass("layui-hide");
		}
	})

	form.on("submit(login-form)", function(data) {
		var loadIndex = layer.load();
		$.ajax({
			type : "post",
			url : "/edu/user/login",
			data : JSON.stringify(data.field),
			contentType : "application/json",
			success : function(result){
				layer.close(loadIndex);
				if(result.code != 200){
					layer.msg(result.message,{icon:5,anim:6});
					return ;
				}
				layer.msg(result.message,{icon:1});
				setTimeout(function(){
					window.location.href = result.data;
				},1500);
			},
			error : function(result){
				layer.close(loadIndex);
				layer.msg("服务器出错",{icon:2});
			}
		})
		
		return false;
	})

})
