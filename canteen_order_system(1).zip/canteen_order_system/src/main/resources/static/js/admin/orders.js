var addUser;
layui.use(['layer', 'element', 'jquery', 'upload', 'form', 'table'], function() {
	var layer = layui.layer;
	var element = layui.element;
	var $ = layui.jquery;
	var upload = layui.upload;
	var form = layui.form;
	var table = layui.table;
	$(".layui-nav-tree .orders-manager").addClass("layui-nav-itemed");
	$(".layui-nav-tree .orders-info").addClass("layui-this");
	
	table.render({
		elem: "#data-table",
		url: "/edu/orders/list",
		request: {
			pageName: "page",
			limitName: "rows"
		},
		page: true,
		response: {
			statusCode: 200,
			statusName: "code",
			countName: "total",
			dataName: "data",
			msgName: "message"
		},
		parseData: function(result) {
			validIsLogin(result);
			if (result.code != 200) {
				return {
					code: result.code,
					message: result.message,
					data: null,
					total: 0
				}
			}

			return {
				code: result.code,
				data: result.data.data,
				total: result.data.total
			}
		},
		cols: [
			[{
					title: "序号",
					type: "numbers",
					fixed: "right"
				},
				{
					title: "订单编号",
					field: "orderNo",
					align: "center",
					unresize: true
				},
				{
					title: "总金额",
					field: "totalPrice",
					align: "center",
					unresize: true
				},
				{
					title: "订单状态",
					field: "totalPrice",
					align: "center",
					unresize: true,
					templet : function(row){
						if(row.status == 0){
							return "待支付";
						}					
						if(row.status == 1){
							return "已支付";
						}
						
						if(row.status == 2){
							return "已完成";
						}
						if(row.status == 3){
							return "取消订单";
						}
						
					}
				},
				{
					title: "创建时间",
					field: "createTime",
					align: "center",
					unresize: true
				},
				{
					title: "更新时间",
					field: "updateTime",
					align: "center",
					unresize: true
				},
				{
					title: "操作",
					align: "center",
					unresize: true,
					templet: function(row) {
						var buttons = "";
						if(row.status == 1){
							buttons +=
								"<button class='layui-btn layui-btn-xs ' onclick='collection(" +
								row.id + ")'>确认收款</button>";
						}
						
						buttons += "<button class='layui-btn layui-btn-xs layui-btn-danger' onclick='deleteOrders(" +
								row.id + ")'>删除</button>";
						return buttons;

					}
				}
			]
		]
	})

	

	deleteOrders=function(id) {
		layer.confirm("确定要删除该订单吗？", {
			title: false,
			closeBtn: false,
			btn: ['取消', '确定'],
			btn2: function(index, layero) {
				var loadIndex = layer.load();
				$.ajax({
					type : "get",
					url : '/edu/orders/delete/' + id,
					success : function(result){
						layer.close(loadIndex);
						validIsLogin(result);
						if (result.code != 200) {
							layer.msg(result.message, {
								icon: 5
							});
							return;
						}
						layer.msg(result.message, {
							icon: 1
						});
						table.reload("data-table");
					}
				})
			}
		})
	}
	
	collection = function(id) {
		layer.confirm("确定已收到该订单金额？", {
			title: false,
			closeBtn: false,
			btn: ['取消', '确定'],
			btn2: function(index, layero) {
				var loadIndex = layer.load();
				$.ajax({
					type : "get",
					url : '/edu/orders/collection/' + id,
					success : function(result){
						layer.close(loadIndex);
						validIsLogin(result);
						if (result.code != 200) {
							layer.msg(result.message, {
								icon: 5
							});
							return;
						}
						layer.msg(result.message, {
							icon: 1
						});
						table.reload("data-table");
					}
				})
			}
		})
	}
})