var addUser;
layui.use(['layer', 'element', 'jquery', 'upload', 'form', 'table','rate'], function() {
	var layer = layui.layer;
	var element = layui.element;
	var $ = layui.jquery;
	var upload = layui.upload;
	var form = layui.form;
	var table = layui.table;
	var rate = layui.rate;
	$(".layui-nav-tree .recipe-manager").addClass("layui-nav-itemed");
	$(".layui-nav-tree .recipe-info").addClass("layui-this");
	var categorys = [];
	
	$(function(){
		$.ajax({
			type : "get",
			url : "/edu/category/all",
			success : function(result){
				if(result.code != 200){
					layer.msg(result.message,{icon:5,anim:6});
					return ;
				}
				categorys = result.data;
			}
		})
	})
	table.render({
		elem: "#data-table",
		url: "/edu/recipe/list",
		request: {
			pageName: "page",
			limitName: "rows"
		},
		page: true,
		response: {
			statusCode: 200,
			statusName: "code",
			countName: "total",
			dataName: "data",
			msgName: "message"
		},
		parseData: function(result) {
			validIsLogin(result);
			if (result.code != 200) {
				return {
					code: result.code,
					message: result.message,
					data: null,
					total: 0
				}
			}

			return {
				code: result.code,
				data: result.data.data,
				total: result.data.total
			}
		},
		cols: [
			[{
					title: "序号",
					type: "numbers",
					fixed: "right"
				},
				{
					title: "名称",
					field: "name",
					align: "center",
					unresize: true
				},
				{
					title: "分类",
					align: "center",
					unresize: true,
					templet : function(row){
						return row.category.name;
					}
				},
				{
					title: "推荐系数",
					align: "center",
					unresize: true,
					templet : function(row){
						return row.recommendScore;
					}
				},
				{
					title: "价格",
					field: "price",
					align: "center",
					unresize: true
				},
				{
					title: "份量",
					field: "weightf",
					align: "center",
					unresize: true
				},
				{
					title: "食材",
					field: "food",
					align: "center",
					unresize: true
				},
				{
					title: "口味",
					field: "taste",
					align: "center",
					unresize: true
				},
				{
					title: "制作方式",
					field: "makeWay",
					align: "center",
					unresize: true
				},
				{
					title: "操作",
					align: "center",
					unresize: true,
					templet: function(row) {
						var buttons = "";
						buttons += "<button class='layui-btn layui-btn-xs' onclick='editRecipe(" +
							row.id + ")'>编辑</button>";
						buttons +=
							"<button class='layui-btn layui-btn-xs layui-btn-danger' onclick='deleteRecipe(" +
							row.id + ")'>删除</button>";
						return buttons;

					}
				}
			]
		]
	})

	addRecipe = function() {
		uwindex = layer.open({
			type: 1,
			title: "新增菜品",
			content: $("#recipe-template").text(),
			btn: ['取消', '确定'],
			area: ["600px", '720px'],
			btn2: function(index, layero) {
				$("#recipe-form").attr("action", "/edu/recipe/add");
				$("#recipe-form #submit-btn").click();
				return false;
			},
			success: function() {
				var options = "<option value=''>请选择</option>";
				
				for(var i=0;i<categorys.length;i++){
					options+="<option value='"+categorys[i].id+"'>"+categorys[i].name+"</option>";
				}
				$("#recipe-form #categoryId").html(options);
				
				rate.render({
					elem:"#recommendScore",
					choose: function(value){
					   $("#recipe-form input[name='recommendScore']").val(value);
					}
				})
				
				form.render();
				upload.render({
					elem: '#imageBtn',
					url: '/upload/file',
					before: function(obj) {
						obj.preview(function(index, file, result) {
							$('#recipe-form #image')
								.attr('src', result);
						});
					},
					accept: "images",
					done: function(result) {
						if (result.code != 200) {
							return layer.msg(result.message, {
								icon: 5
							});
						}
						$("#recipe-form input[name='image']")
							.val(result.data);
					}
				})
			}
		})
	}
	form.on("submit(recipe-form)", function(data) {
		var action = $("#recipe-form").attr("action");
		var params = data.field;
		params.isRecommend = params.isRecommend == "1"?true:false;
		var loadIndex = layer.load();
		$.ajax({
			type: "post",
			url: action,
			data: JSON.stringify(params),
			contentType: "application/json",
			success: function(result) {
				layer.close(loadIndex);
				if (result.code != 200) {
					layer.msg(result.message, {
						icon: 5,
						anim: 6
					});
					return;
				}
				layer.msg(result.message, {
					icon: 1
				});
				layer.close(uwindex);
				table.reload("data-table");
			},
			error: function(result) {
				layer.close(loadIndex);
				layer.msg("服务器出错", {
					icon: 2
				});
			}
		})
	})

	editRecipe = function(id) {
		var loadIndex = layer.load();
		$.ajax({
			type: "get",
			url: '/edu/recipe/' + id,
			success: function(result) {
				layer.close(loadIndex);
				validIsLogin(result);
				if (result.code != 200) {
					layer.msg(result.message, {
						icon: 5
					});
					return;
				}
				var data = result.data;
				uwindex = layer.open({
					type: 1,
					title: "菜品信息",
					content: $("#recipe-template").text(),
					btn: ['取消', '确定'],
					area: ["600px", '720px'],
					btn2: function(index, layero) {
						$("#recipe-form").attr("action", "/edu/recipe/update");
						$("#recipe-form #submit-btn").click();
						return false;
					},
					success: function() {
						var options = "<option value=''>请选择</option>";
						for(var i=0;i<categorys.length;i++){
							options+="<option value='"+categorys[i].id+"'>"+categorys[i].name+"</option>";
						}
						$("#recipe-form #categoryId").html(options);
						form.render();
						form.val("recipe-form", {
							"id": data.id,
							"name": data.name,
							"categoryId": data.categoryId,
							"price": data.price,
							"weightf": data.weightf,
							"taste": data.taste,
							"food": data.food,
							"makeWay": data.makeWay,
							"image": data.image,
							"prompt": data.prompt,
							"recommendScore": data.recommendScore
							
						});
						
						rate.render({
							elem:"#recommendScore",
							value:data.recommendScore,
							choose: function(value){
					   			$("#recipe-form input[name='recommendScore']").val(value);
							}
						})
						
						$("#recipe-form #image").attr("src", "/" + data
							.image);
						upload.render({
							elem: '#imageBtn',
							url: '/upload/file',
							before: function(obj) {
								obj.preview(function(index, file,
									result) {
									$('#recipe-form #image')
										.attr('src',
											result);
								});
							},
							accept: "images",
							done: function(result) {
								if (result.code != 200) {
									return layer.msg(result.message, {
										icon: 5
									});
								}
								$("#recipe-form input[name='image']")
									.val(result
										.data);
							}
						});
					}
				})
			}
		})
	}

	deleteRecipe=function(id) {
		layer.confirm("确定要删除该菜品吗？", {
			title: false,
			closeBtn: false,
			btn: ['取消', '确定'],
			btn2: function(index, layero) {
				var loadIndex = layer.load();
				$.ajax({
					type : "get",
					url : '/edu/recipe/delete/' + id,
					success : function(result){
						layer.close(loadIndex);
						validIsLogin(result);
						if (result.code != 200) {
							layer.msg(result.message, {
								icon: 5
							});
							return;
						}
						layer.msg(result.message, {
							icon: 1
						});
						table.reload("data-table");
					}
				})
			}
		})
	}
})