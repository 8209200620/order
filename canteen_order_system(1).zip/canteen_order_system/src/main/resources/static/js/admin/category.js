var addUser;
layui.use(['layer', 'element', 'jquery', 'upload', 'form', 'table'], function() {
	var layer = layui.layer;
	var element = layui.element;
	var $ = layui.jquery;
	var upload = layui.upload;
	var form = layui.form;
	var table = layui.table;
	$(".layui-nav-tree .category-manager").addClass("layui-nav-itemed");
	$(".layui-nav-tree .category-info").addClass("layui-this");
	table.render({
		elem: "#data-table",
		url: "/edu/category/list",
		request: {
			pageName: "page",
			limitName: "rows"
		},
		page: true,
		response: {
			statusCode: 200,
			statusName: "code",
			countName: "total",
			dataName: "data",
			msgName: "message"
		},
		parseData: function(result) {
			validIsLogin(result);
			if (result.code != 200) {
				return {
					code: result.code,
					message: result.message,
					data: null,
					total: 0
				}
			}

			return {
				code: result.code,
				data: result.data.data,
				total: result.data.total
			}
		},
		cols: [
			[{
					title: "序号",
					type: "numbers",
					fixed: "right"
				},
				{
					title: "名称",
					field: "name",
					align: "center",
					unresize: true
				},
				{
					title: "创建时间",
					field: "createTime",
					align: "center",
					unresize: true
				},
				{
					title: "更新时间",
					field: "updateTime",
					align: "center",
					unresize: true
				},
				{
					title: "操作",
					align: "center",
					unresize: true,
					templet: function(row) {
						var buttons = "";
						buttons += "<button class='layui-btn layui-btn-xs' onclick='editCategory(" +
							row.id + ")'>编辑</button>";
						buttons +=
							"<button class='layui-btn layui-btn-xs layui-btn-danger' onclick='deleteCategory(" +
							row.id + ")'>删除</button>";
						return buttons;

					}
				}
			]
		]
	})

	addCategory = function() {
		uwindex = layer.open({
			type: 1,
			title: "新增分类",
			content: $("#category-template").text(),
			btn: ['取消', '确定'],
			btn2: function(index, layero) {
				$("#category-form").attr("action", "/edu/category/add");
				$("#category-form #submit-btn").click();
				return false;
			},
			success: function() {
				form.render();
			}
		})
	}
	form.on("submit(category-form)", function(data) {
		var action = $("#category-form").attr("action");
		var params = data.field;
		var loadIndex = layer.load();
		$.ajax({
			type: "post",
			url: action,
			data: JSON.stringify(params),
			contentType: "application/json",
			success: function(result) {
				layer.close(loadIndex);
				if (result.code != 200) {
					layer.msg(result.message, {
						icon: 5,
						anim: 6
					});
					return;
				}
				layer.msg(result.message, {
					icon: 1
				});
				layer.close(uwindex);
				table.reload("data-table");
			},
			error: function(result) {
				layer.close(loadIndex);
				layer.msg("服务器出错", {
					icon: 2
				});
			}
		})
	})

	editCategory = function(id) {
		var loadIndex = layer.load();
		$.ajax({
			type: "get",
			url: '/edu/category/' + id,
			success: function(result) {
				layer.close(loadIndex);
				validIsLogin(result);
				if (result.code != 200) {
					layer.msg(result.message, {
						icon: 5
					});
					return;
				}
				var data = result.data;
				uwindex = layer.open({
					type: 1,
					title: "分类信息",
					content: $("#category-template").text(),
					btn: ['取消', '确定'],
					btn2: function(index, layero) {
						$("#category-form").attr("action", "/edu/category/update");
						$("#category-form #submit-btn").click();
						return false;
					},
					success: function() {
						form.render();
						form.val("category-form", {
							"id": data.id,
							"name": data.name
						})
					}
				})
			}
		})
	}

	deleteCategory = function(id) {
		layer.confirm("确定要删除该分类吗？", {
			title: false,
			closeBtn: false,
			btn: ['取消', '确定'],
			btn2: function(index, layero) {
				var loadIndex = layer.load();
				$.ajax({
					type : "get",
					url : '/edu/category/delete/' + id,
					success : function(result){
						layer.close(loadIndex);
						validIsLogin(result);
						if (result.code != 200) {
							layer.msg(result.message, {
								icon: 5
							});
							return;
						}
						layer.msg(result.message, {
							icon: 1
						});
						table.reload("data-table");
					}
				})
			}
		})
	}
})