var addUser;
layui.use(['layer', 'element', 'jquery', 'upload', 'form', 'table'], function() {
	var layer = layui.layer;
	var element = layui.element;
	var $ = layui.jquery;
	var upload = layui.upload;
	var form = layui.form;
	var table = layui.table;
	$(".layui-nav-tree .user-manager").addClass("layui-nav-itemed");
	$(".layui-nav-tree .user-info").addClass("layui-this");
	table.render({
		elem: "#user-table",
		url: "/edu/user/list",
		request: {
			pageName: "page",
			limitName: "rows"
		},
		page: true,
		response: {
			statusCode: 200,
			statusName: "code",
			countName: "total",
			dataName: "data",
			msgName: "message"
		},
		parseData: function(result) {
			validIsLogin(result);
			if (result.code != 200) {
				return {
					code: result.code,
					message: result.message,
					data: null,
					total: 0
				}
			}

			return {
				code: result.code,
				data: result.data.data,
				total: result.data.total
			}
		},
		cols: [
			[{
					title: "序号",
					type: "numbers",
					fixed: "right"
				},
				{
					title: "手机号码",
					field: "account",
					align: "center",
					unresize: true
				},
				{
					title: "姓名",
					field: "name",
					align: "center",
					unresize: true
				},
				{
					title: "手机号码",
					field: "mobile",
					align: "center",
					unresize: true
				},
				{
					title: "年龄",
					field: "age",
					align: "center",
					unresize: true
				},
				{
					title: "性别",
					align: "center",
					unresize: true,
					templet: function(row) {
						if (row.sex) {
							return "男";
						}
						return "女";
					}
				},
				{
					title: "用户类型",
					align: "center",
					unresize: true,
					templet: function(row) {
						if (row.type == 3) {
							return "服务员";
						}
						if (row.type == 2) {
							return "后厨";
						}
						return "普通用户";
					}
				},
				{
					title: "操作",
					align: "center",
					unresize: true,
					width: 200,
					fixed: "right",
					templet: function(row) {
						var buttons = "";
						buttons += "<button class='layui-btn layui-btn-xs' onclick='editUser(" +
							row.id + ")'>编辑</button>";
						buttons +=
							"<button class='layui-btn layui-btn-xs layui-btn-danger' onclick='deleteUser(" +
							row.id + ")'>删除</button>";
						return buttons;

					}
				}
			]
		]
	})

	addUser = function() {
		uwindex = layer.open({
			type: 1,
			title: "新增用户",
			content: $("#user-template").text(),
			btn: ['取消', '确定'],
			area: ["560px", '500px'],
			btn2: function(index, layero) {
				$("#user-form").attr("action", "/edu/user/add");
				$("#user-form #submit-btn").click();
				return false;
			},
			success: function() {
				form.render();
				upload.render({
					elem: '#headerImageBtn',
					url: '/upload/file',
					before: function(obj) {
						obj.preview(function(index, file, result) {
							$('#user-form #headerImage')
								.attr('src', result);
						});
					},
					accept: "images",
					done: function(result) {
						if (result.code != 200) {
							return layer.msg(result.message, {
								icon: 5
							});
						}
						$("#user-form input[name='headerImage']")
							.val(result.data);
					}
				})
				$("#account").removeAttr("readonly");
			}
		})
	}
	form.on("submit(user-form)", function(data) {
		var action = $("#user-form").attr("action");
		var params = data.field;
		params.sex = params.sex == "1" ? true : false;
		var loadIndex = layer.load();
		$.ajax({
			type: "post",
			url: action,
			data: JSON.stringify(params),
			contentType: "application/json",
			success: function(result) {
				layer.close(loadIndex);
				if (result.code != 200) {
					layer.msg(result.message, {
						icon: 5,
						anim: 6
					});
					return;
				}
				layer.msg(result.message, {
					icon: 1
				});
				layer.close(uwindex);
				table.reload("user-table");
			},
			error: function(result) {
				layer.close(loadIndex);
				layer.msg("服务器出错", {
					icon: 2
				});
			}
		})
	})

	editUser = function(id) {
		var loadIndex = layer.load();
		$.ajax({
			type: "get",
			url: '/edu/user/' + id,
			success: function(result) {
				layer.close(loadIndex);
				validIsLogin(result);
				if (result.code != 200) {
					layer.msg(result.message, {
						icon: 5
					});
					return;
				}
				var data = result.data;
				uwindex = layer.open({
					type: 1,
					title: "用户信息",
					content: $("#user-template").text(),
					btn: ['取消', '确定'],
					area: ["560px", '500px'],
					btn2: function(index, layero) {
						$("#user-form").attr("action", "/edu/user/update");
						$("#user-form #submit-btn").click();
						return false;
					},
					success: function() {
						form.render();
						form.val("user-form", {
							"id": data.id,
							"account": data.account,
							"password": data.password,
							"name": data.name,
							"sex": data.sex == true ? "1" : "0",
							"mobile": data.mobile,
							"type": data.type,
							"age": data.age,
							"headerImage": data.headerImage,
						});

						$("#user-form #headerImage").attr("src", "/" + data
							.headerImage);
						upload.render({
							elem: '#headerImageBtn',
							url: '/upload/file',
							before: function(obj) {
								obj.preview(function(index, file,
									result) {
									$('#user-form #headerImage')
										.attr('src',
											result);
								});
							},
							accept: "images",
							done: function(result) {
								if (result.code != 200) {
									return layer.msg(result.message, {
										icon: 5
									});
								}
								$("#user-form input[name='headerImage']")
									.val(result
										.data);
							}
						});
					}
				})
			}
		})
	}

	deleteUser=function(id) {
		layer.confirm("确定要删除该用户吗？", {
			title: false,
			closeBtn: false,
			btn: ['取消', '确定'],
			btn2: function(index, layero) {
				var loadIndex = layer.load();
				$.ajax({
					type : "get",
					url : '/edu/user/delete/' + id,
					success : function(result){
						layer.close(loadIndex);
						validIsLogin(result);
						if (result.code != 200) {
							layer.msg(result.message, {
								icon: 5
							});
							return;
						}
						layer.msg(result.message, {
							icon: 1
						});
						table.reload("user-table");
					}
				})
			}
		})
	}
})