var uwindex;
layui.use(['layer','jquery','form','upload','table','element'],function(){
	var layer = layui.layer;
	var $ = layui.jquery;
	var form = layui.form;
	var upload = layui.upload;
	var table = layui.table;
	var element = layui.element;
	element.render();
	$(".layui-nav-tree .carousel-manager").addClass("layui-nav-itemed");
	$(".layui-nav-tree .carousel-info").addClass("layui-this");
	
	upload.render({
	    elem: '#addBtn'
	    ,url: '/edu/carousel/add' 
		,accept : "images"
	    ,done: function(result){
	        if(result.code != 200){
	          return layer.msg(result.message,{icon:5});
	        }
	        table.reload("data-table");
	      }
	  });
	table.render({
		elem : "#data-table",
		url : "/edu/carousel/list",
		request : {
			pageName : "page",
			limitName : "rows"
		},
		page:true,
		response : {
			statusCode  : 200,
			statusName : "code",
			countName : "total",
			dataName : "data",
			msgName : "message"
		},
		parseData : function(result){
			validIsLogin(result);
			if(result.code != 200){
				return {
					code : result.code,
					message : result.message,
					data: null,
					total : 0
				}
			}
			
			return {
				code : result.code,
				data : result.data.data,
				total : result.data.total
			}
		},
		cols : [[
			{
				title : "序号",
				type : "numbers"
			},
			{
				title : "路径",
				field : "path",
				align : "center",
			},
			{
				title : "是否显示",
				field : "isShow",
				align : "center",
				templet : function(row){
					if(row.isShow){
						return "<input type='checkbox' checked=''  name='open' lay-skin='switch' lay-filter='updateCarousel' value='"+row.id+"' lay-text='是|否'>";
					}else{
						return "<input type='checkbox' name='close' lay-skin='switch' lay-filter='updateCarousel' value='"+row.id+"' lay-text='是|否'>";
					}
				}
			},
			{
				title : "发布时间",
				field : "createTime",
				align : "center",
			},
			{
				title : "管理",
				align : "center",
				fixed : "right",
				templet : function(row){
					var buttons = "";
					buttons += "<button type='button' class='layui-btn layui-btn-xs layui-btn-danger' onclick='deleteCarousel("+row.id+")'>删除</button>";
					return buttons;
				}
			}
		]]
	})
	
	form.on('switch(updateCarousel)', function(data){
		var id = data.value;
		var isShow = this.checked ? true : false;
		$.ajax({
			type : "post",
			url : "/edu/carousel/update",
			data : JSON.stringify({
				id : id,
				isShow : isShow
			}),
			contentType : "application/json",
			success : function(result){
				if(result.code != 200){
					layer.msg(result.message,{icon:5,anim:6});
					return ;
				}
				layer.msg(result.message,{icon:1});
				table.reload("data-table");
			}
		})
    });
	deleteCarousel = function(id){
		layer.confirm("确定要删除该轮播图吗？",{
			title : false,
			closeBtn : false,
			btn : ['取消','确定'],
			btn2 : function(index,layero){
				var loadIndex = layer.load();
				$.ajax({
					type : "get",
					url : "/edu/carousel/delete/"+id,
					success : function(result){
						layer.close(loadIndex);
						if(result.code != 200){
							layer.msg(result.message,{icon:5,anim:6});
							return ;
						}
						layer.msg(result.message,{icon:1});
						table.reload("data-table");
					}
				})
			}
		});
	}
});