package edu.canteen.order.system.mapper;

import edu.canteen.order.system.pojo.UserMessage;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 */
public interface UserMessageMapper extends BaseMapper<UserMessage> {

}
