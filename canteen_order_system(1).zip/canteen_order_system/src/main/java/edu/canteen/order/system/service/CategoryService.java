package edu.canteen.order.system.service;

import com.baomidou.mybatisplus.extension.service.IService;

import edu.canteen.order.system.pojo.Category;

/**
 * <p>
 * 分类表 服务类
 * </p>
 *
 */
public interface CategoryService extends IService<Category> {

}
