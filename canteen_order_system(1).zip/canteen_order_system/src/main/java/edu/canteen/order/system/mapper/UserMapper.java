package edu.canteen.order.system.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;

import edu.canteen.order.system.pojo.User;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 */
public interface UserMapper extends BaseMapper<User> {

}
